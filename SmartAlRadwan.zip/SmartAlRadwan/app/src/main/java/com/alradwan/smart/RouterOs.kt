package com.alradwan.smart

import java.io.Closeable
import java.io.DataInputStream
import java.io.EOFException
import java.io.IOException
import java.net.InetSocketAddress
import java.net.Socket
import java.security.MessageDigest

/** عميل مبسّط لبروتوكول RouterOS API الموثّق من MikroTik (المنفذ 8728، بدون تشفير). */
class RouterOs(host: String, port: Int = 8728) : Closeable {
    private val socket = Socket().apply { connect(InetSocketAddress(host, port), 5000); soTimeout = 15000 }
    private val ins = DataInputStream(socket.getInputStream().buffered())
    private val out = socket.getOutputStream().buffered()

    fun login(user: String, pass: String) {
        // الإصدارات الجديدة ترد بـ !done مباشرة، والقديمة (قبل 6.43) ترسل challenge في =ret=
        val ch = call("/login", "=name=$user", "=password=$pass").firstOrNull()?.get("ret") ?: return
        val md = MessageDigest.getInstance("MD5")
        md.update(0.toByte()); md.update(pass.toByteArray()); md.update(ch.chunked(2).map { it.toInt(16).toByte() }.toByteArray())
        call("/login", "=name=$user", "=response=00" + md.digest().joinToString("") { "%02x".format(it) })
    }

    /** يرسل أمراً ويعيد الصفوف (!re) كخرائط مفتاح/قيمة. يرمي IOException عند !trap. */
    fun call(vararg words: String): List<Map<String, String>> {
        for (w in words) { val b = w.toByteArray(Charsets.UTF_8); writeLen(b.size); out.write(b) }
        out.write(0); out.flush()
        val rows = ArrayList<Map<String, String>>()
        var error: String? = null
        while (true) {
            val s = sentence()
            if (s.isEmpty()) continue
            val attrs = HashMap<String, String>()
            for (w in s.drop(1)) if (w.startsWith("=")) {
                val i = w.indexOf('=', 1)
                if (i > 0) attrs[w.substring(1, i)] = w.substring(i + 1) else attrs[w.substring(1)] = ""
            }
            when (s[0]) {
                "!re" -> rows += attrs
                "!trap" -> error = attrs["message"] ?: "trap"
                "!fatal" -> throw IOException(s.getOrNull(1) ?: "fatal")
                "!done" -> { if (error != null) throw IOException(error); if (attrs.isNotEmpty()) rows += attrs; return rows }
            }
        }
    }

    private fun rb(): Int { val b = ins.read(); if (b < 0) throw EOFException(); return b }

    private fun sentence(): List<String> {
        val words = ArrayList<String>()
        while (true) {
            val n = readLen()
            if (n == 0) return words
            val b = ByteArray(n); ins.readFully(b); words += String(b, Charsets.UTF_8)
        }
    }

    private fun readLen(): Int {
        val b = rb()
        return when {
            b < 0x80 -> b
            b < 0xC0 -> ((b and 0x3F) shl 8) or rb()
            b < 0xE0 -> ((b and 0x1F) shl 16) or (rb() shl 8) or rb()
            b < 0xF0 -> ((b and 0x0F) shl 24) or (rb() shl 16) or (rb() shl 8) or rb()
            else -> (rb() shl 24) or (rb() shl 16) or (rb() shl 8) or rb()
        }
    }

    private fun writeLen(n: Int) {
        when {
            n < 0x80 -> out.write(n)
            n < 0x4000 -> { out.write((n shr 8) or 0x80); out.write(n and 0xFF) }
            n < 0x200000 -> { out.write((n shr 16) or 0xC0); out.write((n shr 8) and 0xFF); out.write(n and 0xFF) }
            else -> { out.write((n shr 24) or 0xE0); out.write((n shr 16) and 0xFF); out.write((n shr 8) and 0xFF); out.write(n and 0xFF) }
        }
    }

    override fun close() { runCatching { socket.close() } }
}
