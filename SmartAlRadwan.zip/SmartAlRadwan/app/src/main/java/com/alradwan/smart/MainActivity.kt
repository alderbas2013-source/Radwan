package com.alradwan.smart

import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Bundle
import android.text.InputType
import android.view.View
import android.widget.*
import java.io.IOException
import java.security.SecureRandom
import kotlin.concurrent.thread

class MainActivity : Activity() {
    private val f = HashMap<String, EditText>()
    private lateinit var log: TextView
    private lateinit var same: CheckBox
    @Volatile private var lastCards = ""

    private fun v(k: String) = f[k]!!.text.toString().trim()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(40, 40, 40, 40); layoutDirection = View.LAYOUT_DIRECTION_RTL
        }
        root.addView(TextView(this).apply { text = "سمارت الرضوان"; textSize = 24f })

        fun field(k: String, h: String, d: String = "", pw: Boolean = false, num: Boolean = false) {
            f[k] = EditText(this).apply {
                hint = h; setText(d); setSingleLine()
                inputType = if (pw) InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
                else if (num) InputType.TYPE_CLASS_NUMBER else InputType.TYPE_CLASS_TEXT
            }
            root.addView(f[k])
        }
        fun button(label: String, click: () -> Unit) =
            root.addView(Button(this).apply { text = label; setOnClickListener { click() } })

        field("ip", "عنوان الراوتر", "192.168.88.1")
        field("port", "منفذ API", "8728", num = true)
        field("user", "اسم المستخدم", "admin")
        field("pass", "كلمة المرور", pw = true)
        field("count", "عدد الكروت", "10", num = true)
        field("profile", "البروفايل", "default")
        field("prefix", "بادئة الكرت", "SR")
        field("len", "عدد أرقام الكرت", "6", num = true)
        field("limit", "المدة مثل 1d أو 10h (اختياري)")
        same = CheckBox(this).apply { text = "كلمة السر = اسم الكرت"; isChecked = true }
        root.addView(same)

        button("اختبار الاتصال") {
            withRouter { r ->
                val x = r.call("/system/resource/print").firstOrNull().orEmpty()
                "متصل ✓\nالجهاز: ${x["board-name"]}\nالإصدار: ${x["version"]}\nمدة التشغيل: ${x["uptime"]}"
            }
        }
        button("إنشاء كروت") {
            val n = (v("count").toIntOrNull() ?: 0).coerceIn(1, 500)
            val prof = v("profile").ifBlank { "default" }
            val pre = v("prefix"); val len = (v("len").toIntOrNull() ?: 6).coerceIn(4, 12)
            val lim = v("limit"); val sameAsUser = same.isChecked
            withRouter { r ->
                val rnd = SecureRandom(); val sb = StringBuilder(); var ok = 0; var err = ""
                fun digits() = (1..len).joinToString("") { rnd.nextInt(10).toString() }
                repeat(n) {
                    val name = pre + digits(); val pw = if (sameAsUser) name else digits()
                    val a = arrayListOf("/ip/hotspot/user/add", "=name=$name", "=password=$pw", "=profile=$prof", "=comment=SmartAlRadwan")
                    if (lim.isNotBlank()) a.add("=limit-uptime=$lim")
                    try { r.call(*a.toTypedArray()); ok++; sb.append(name).append(if (sameAsUser) "\n" else "  $pw\n") }
                    catch (e: IOException) { if (err.isEmpty()) err = e.message ?: "" }
                }
                lastCards = sb.toString()
                "تم إنشاء $ok من $n" + (if (err.isNotEmpty()) "\nآخر خطأ: $err" else "") + "\n\n$lastCards"
            }
        }
        button("نسخ الكروت") {
            (getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager).setPrimaryClip(ClipData.newPlainText("cards", lastCards))
            Toast.makeText(this, "تم النسخ", Toast.LENGTH_SHORT).show()
        }
        button("عرض المستخدمين") {
            withRouter { r ->
                val rows = r.call("/ip/hotspot/user/print")
                "عدد المستخدمين: ${rows.size}\n" + rows.take(100).joinToString("\n") { "${it["name"]}  [${it["profile"]}]  ${it["uptime"].orEmpty()}" }
            }
        }
        button("المتصلون الآن") {
            withRouter { r ->
                val rows = r.call("/ip/hotspot/active/print")
                "المتصلون الآن: ${rows.size}\n" + rows.joinToString("\n") { "${it["user"]}  ${it["address"]}  ${it["uptime"]}" }
            }
        }
        button("إعادة تشغيل الراوتر") {
            AlertDialog.Builder(this).setMessage("إعادة تشغيل الراوتر الآن؟").setNegativeButton("إلغاء", null)
                .setPositiveButton("تأكيد") { _, _ -> withRouter { r -> runCatching { r.call("/system/reboot") }; "أُرسل أمر إعادة التشغيل" } }.show()
        }

        log = TextView(this).apply { setTextIsSelectable(true); setPadding(0, 24, 0, 0) }
        root.addView(log)
        setContentView(ScrollView(this).apply { addView(root) })
    }

    /** يتصل بالراوتر في خيط خلفي وينفّذ الأمر ثم يعرض النتيجة. */
    private fun withRouter(block: (RouterOs) -> String) {
        val host = v("ip"); val port = v("port").toIntOrNull() ?: 8728
        val user = v("user"); val pass = f["pass"]!!.text.toString()
        log.text = "جارٍ الاتصال…"
        thread {
            val msg = try { RouterOs(host, port).use { it.login(user, pass); block(it) } }
            catch (e: Exception) { "خطأ: ${e.message}" }
            runOnUiThread { log.text = msg }
        }
    }
}
